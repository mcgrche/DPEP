---
name: Feature request
about: Suggest an improvement for the project
---

## Problem
What is missing or inconvenient?

## Proposed solution
What would you like to add or improve?

## Why it matters
How would this help the project?
